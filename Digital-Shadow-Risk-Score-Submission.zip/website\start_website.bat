@echo off
setlocal
cd /d "%~dp0.."

where python >nul 2>&1
if errorlevel 1 (
  echo Python was not found. Install Python 3 and enable "Add Python to PATH".
  pause
  exit /b 1
)

python -m pip install -r website\requirements.txt
if errorlevel 1 (
  echo Dependency installation failed. Check your internet connection and Python installation.
  pause
  exit /b 1
)

set "WEBSITE_PORT="
for /f %%P in ('powershell -NoProfile -Command "$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 0); $listener.Start(); $port = $listener.LocalEndpoint.Port; $listener.Stop(); Write-Output $port"') do set "WEBSITE_PORT=%%P"
if not defined WEBSITE_PORT (
  echo Could not find an available local port for the website.
  pause
  exit /b 1
)

set "DIGITAL_SHADOW_PORT=%WEBSITE_PORT%"
start "" /b powershell -NoProfile -Command "$url = 'http://127.0.0.1:%WEBSITE_PORT%'; $deadline = (Get-Date).AddMinutes(2); while ((Get-Date) -lt $deadline) { try { $response = Invoke-WebRequest -Uri $url -TimeoutSec 2; if ($response.StatusCode -eq 200) { Start-Process $url; exit 0 } } catch { }; Start-Sleep -Seconds 1 }; Write-Host 'The website did not become ready. Check the Python errors in this window.'"
python website\app.py
if errorlevel 1 (
  echo The website stopped because it encountered an error.
  pause
)
