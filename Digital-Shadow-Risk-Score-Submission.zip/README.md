# Digital Shadow Risk Score — Submission Package

This is a curated, self-contained copy of the final website and the URL
phishing classifier it uses. The source website in the original project
folders was not modified.

## What is included

- `website\`: the final Flask site, its static assets, and the one-click
  launcher.
- `Final\url_svm_output\`: the exact saved SVM model and its evaluation.
- `Final\phishing_url_cleaned_100000.csv`: the balanced dataset used to train
  the final model.
- `Final\phishing_url_project.py`: code to reproduce the SVM training and
  evaluation from the included cleaned dataset.
- `Final\dataset_eda\`: charts used to explain the dataset.
- `notebooks\Final_Model_Study_Guide.ipynb`: a guided tour of the data,
  evaluation, and model code.

The original workbook, duplicate/older Decision Tree models, cached files,
and intermediate ZIP copies are intentionally excluded. The cleaned dataset
is included, so the final SVM can be retrained without the original workbook.

## Start the website

Extract the ZIP and keep the folders together. From this folder, either
double-click `website\start_website.bat` or run:

```powershell
python -m pip install -r website\requirements.txt
python website\app.py
```

The website expects the model at
`Final\url_svm_output\phishing_url_model.joblib`. Do not move files out of
their folders.

## Publish it for your teacher

The batch file above starts a local-only server. To get a public URL, deploy
this package to a hosting provider. This project includes a Render Blueprint
in `render.yaml` that configures Gunicorn, dependency installation, and a
health check. Follow Render's
[Flask deployment guide](https://render.com/docs/deploy-flask) for the current
dashboard steps. The Flask development server remains local-only.

1. Use GitHub Desktop to add this extracted submission folder as a local
   repository, then publish it as a **private GitHub repository**. The cleaned
   dataset is larger than GitHub's per-file browser upload limit, so don't
   upload the files through the GitHub website. Keep `render.yaml` and the
   `Final` and `website` folders at the repository root.
2. In Render, create a new **Blueprint** and connect that repository. Review
   the service settings from `render.yaml` and deploy.
3. After the first deploy succeeds, open the `onrender.com` URL shown in the
   Render dashboard and share that URL with your teacher.

Render needs access to the repository to deploy it; the repository itself can
remain private. A free service may sleep when idle, so the first visit after a
period of inactivity can take a little while to load. Test the public URL
from a different network (for example, your phone with Wi-Fi turned off)
before the presentation.

## Reproduce the final model

```powershell
python -m pip install -r Final\requirements.txt
python Final\phishing_url_project.py
```

This uses a stratified 80/20 split with seed 117 and recreates the model,
metrics, confusion matrix, charts, and split CSVs under `Final\`. Training can
take several minutes. The original workbook and the separate data-preparation
script are not part of this runtime-focused submission copy.

## Final model results

The website uses a Character n-gram Linear SVM. Label `0` means legitimate
and label `1` means phishing. On the held-out test set:

| Metric | Result |
| --- | ---: |
| Accuracy | 97.87% |
| Phishing precision | 98.26% |
| Phishing recall | 97.47% |
| Phishing F1-score | 97.86% |

The SVM reached its configured iteration limit. These are held-out results,
not a guarantee of future performance. The website's URL score is based on a
decision margin, not a calibrated probability.
