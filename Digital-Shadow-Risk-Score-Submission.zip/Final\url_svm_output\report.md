# URL Phishing Classifier Results

- Model: Character n-gram Linear SVM
- Accuracy: 97.87%
- Precision for phishing: 98.26%
- Recall for phishing: 97.47%
- F1-score for phishing: 97.86%
- Training rows: 80,000
- Test rows: 20,000
- Random seed: 117

Label 1 means phishing; label 0 means legitimate. These results are measured
on a held-out portion of this dataset and do not guarantee future performance.
The SVM may show a convergence warning because it reached its configured
iteration limit; report this caveat with the result.

## Classification report

```text
              precision    recall  f1-score   support

  Legitimate       0.97      0.98      0.98     10000
    Phishing       0.98      0.97      0.98     10000

    accuracy                           0.98     20000
   macro avg       0.98      0.98      0.98     20000
weighted avg       0.98      0.98      0.98     20000
```
