const assessmentForm = document.querySelector("#assessment-form");
const urlForm = document.querySelector("#url-form");
const urlButton = document.querySelector("#url-button");
const assessmentMessage = document.querySelector("#assessment-message");
const urlMessage = document.querySelector("#url-message");
const urlResult = document.querySelector("#url-result");

let phishingScore = null;
let assessmentAnswers = null;
const recommendationText = {
  privacy: "Limit profile visibility and review what personal details are public.",
  identity: "Use unique passwords and enable multi-factor authentication.",
  impersonation: "Verify urgent voice or video requests through a trusted channel.",
  phishing: "Open trusted sites directly instead of following unexpected links.",
};

function setMessage(element, text, isError = false) {
  element.textContent = text;
  element.classList.toggle("error", isError);
}

async function postJson(path, payload) {
  const response = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.error || "The request could not be completed.");
  }
  return data;
}

function collectAnswers() {
  const groups = ["privacy", "identity", "impersonation"];
  return Object.fromEntries(
    groups.map((group) => [
      group,
      [1, 2, 3].map((index) =>
        Number(
          assessmentForm.querySelector(
            `input[name="${group}_${index}"]:checked`,
          ).value,
        ),
      ),
    ]),
  );
}

function setComponent(group, component) {
  const element = document.querySelector(`#${group}-score`);
  element.textContent = component.score === null ? "Not checked" : `${component.score}/100`;
}

function renderRecommendations(components) {
  const list = document.querySelector("#recommendations");
  const ranked = Object.entries(components)
    .filter(([, component]) => component.score !== null)
    .sort((left, right) => right[1].score - left[1].score)
    .slice(0, 3);
  list.replaceChildren();

  for (const [index, [group]] of ranked.entries()) {
    const item = document.createElement("li");
    const number = document.createElement("span");
    const advice = document.createElement("p");
    number.textContent = String(index + 1).padStart(2, "0");
    advice.textContent = recommendationText[group];
    item.append(number, advice);
    list.append(item);
  }
}

function renderAssessment(result) {
  document.querySelector("#overall-score").textContent = result.overall_score;
  const level = document.querySelector("#overall-level");
  level.textContent = `${result.overall_level} risk`;
  level.className = `risk-pill ${result.overall_level.toLowerCase()}`;

  const caption = document.querySelector("#score-caption");
  caption.textContent = result.components.phishing.score === null
    ? "Questionnaire score shown. Check a URL to include phishing risk."
    : "Combines questionnaire rules with an SVM margin-based URL risk indicator, not a probability.";

  for (const group of ["privacy", "identity", "impersonation", "phishing"]) {
    setComponent(group, result.components[group]);
  }
  renderRecommendations(result.components);
}

assessmentForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!assessmentForm.reportValidity()) {
    return;
  }

  assessmentAnswers = collectAnswers();
  setMessage(assessmentMessage, "Calculating your score…");
  try {
    const result = await postJson("/api/assess", {
      answers: assessmentAnswers,
      phishing_score: phishingScore,
    });
    renderAssessment(result);
    setMessage(assessmentMessage, "Your score has been updated.");
  } catch (error) {
    setMessage(assessmentMessage, error.message, true);
  }
});

urlForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  urlResult.hidden = true;
  setMessage(urlMessage, "");
  urlButton.disabled = true;
  urlButton.textContent = "Checking…";

  try {
    const result = await postJson("/api/check-url", {
      url: document.querySelector("#url-input").value,
    });
    phishingScore = result.phishing_score;
    urlResult.classList.toggle("phishing", result.classification === "Phishing");
    document.querySelector("#url-result-mark").textContent =
      result.classification === "Phishing" ? "!" : "✓";
    document.querySelector("#url-result-title").textContent = result.classification;
    document.querySelector("#url-result-copy").textContent =
      `${result.note} Risk indicator: ${result.phishing_score}/100.`;
    document.querySelector("#url-result-score").textContent =
      `Risk ${result.phishing_score}/100`;
    urlResult.hidden = false;
    setMessage(urlMessage, "URL check complete.");

    if (assessmentAnswers) {
      renderAssessment(await postJson("/api/assess", {
        answers: assessmentAnswers,
        phishing_score: phishingScore,
      }));
      setMessage(assessmentMessage, "Your overall score now includes the URL check.");
    } else {
      document.querySelector("#phishing-score").textContent = `${phishingScore}/100`;
      setMessage(urlMessage, "Complete the questionnaire to see your combined score.");
    }
  } catch (error) {
    setMessage(urlMessage, error.message, true);
  } finally {
    urlButton.disabled = false;
    urlButton.innerHTML = 'Check URL <span aria-hidden="true">↗</span>';
  }
});
