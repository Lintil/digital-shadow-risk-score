# Final URL phishing model

This folder contains the final website model, its cleaned training data, the
training/evaluation script, and final result charts.

- `phishing_url_cleaned_100000.csv`: 100,000 balanced rows (50,000 per class),
  with URL text, binary labels, and numeric URL features.
- `phishing_url_project.py`: trains the final Character n-gram Linear SVM and
  saves evaluation artifacts.
- `url_svm_output\phishing_url_model.joblib`: saved model consumed by
  `website\app.py`.
- `url_svm_output\metrics.csv`, `confusion_matrix.csv`, `report.md`, and
  `confusion_matrix.png`: held-out evaluation results.
- `dataset_eda\`: dataset exploration charts.

The train/test split is stratified (80/20) with seed 117. The training script
can recreate the saved split and results from the included cleaned CSV. The
source workbook and the data-cleaning script are intentionally not included;
they are not needed to run the site or retrain from this cleaned dataset.

Label `0` is legitimate and label `1` is phishing. The saved evaluation is
97.87% accuracy, 98.26% phishing precision, 97.47% phishing recall, and
97.86% phishing F1. The SVM reached its configured 2,000-iteration limit.
