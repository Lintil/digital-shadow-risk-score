"""Make dataset graphs, save reproducible splits, and train the URL SVM."""

from pathlib import Path

import joblib
import matplotlib
import numpy as np

# Save graphs to image files without opening pop-up windows.
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC


# Keep the existing cleaned dataset: changing its rows can change the scores.
PROJECT_FOLDER = Path(__file__).parent
DATA_FILE = PROJECT_FOLDER / "phishing_url_cleaned_100000.csv"
GRAPH_FOLDER = PROJECT_FOLDER / "dataset_eda"
RESULT_FOLDER = PROJECT_FOLDER / "url_svm_output"
SPLIT_FOLDER = PROJECT_FOLDER / "splits"

URL_COLUMN = "url"
LABEL_COLUMN = "label"
RANDOM_SEED = 117


def make_dataset_graphs(data, number_features):
    """Create charts describing the cleaned dataset."""
    GRAPH_FOLDER.mkdir(parents=True, exist_ok=True)

    # Graph 1: number of legitimate and phishing URLs.
    counts = data[LABEL_COLUMN].value_counts().sort_index()
    plt.figure(figsize=(7, 4))
    bars = plt.bar(["Legitimate (0)", "Phishing (1)"], counts.values)
    plt.bar_label(bars)
    plt.title("Number of URLs in Each Class")
    plt.ylabel("Number of URLs")
    plt.tight_layout()
    plt.savefig(GRAPH_FOLDER / "label_distribution.png", dpi=150)
    plt.close()

    plt.figure(figsize=(7, 4))
    counts = data["label"].value_counts().sort_index()
    bars = plt.bar(
        [0, 1],
        [counts.get(0, 0), counts.get(1, 0)],
        width=0.72,
        color=["#4472C4", "#ED7D31"],
    )
    plt.xticks([0, 1], ["Legitimate (0)", "Phishing (1)"])
    plt.ylim(0, max(counts.values) * 1.16)
    plt.bar_label(bars, labels=[f"{counts.get(label, 0):,}" for label in (0, 1)], padding=3)
    plt.title("Label Histogram — Legitimate vs Phishing")
    plt.xlabel("Class label")
    plt.ylabel("Number of URLs")
    plt.tight_layout()
    plt.savefig(GRAPH_FOLDER / "label_class_histogram.png", dpi=150)
    plt.close()

    # Graph 2: compare URL lengths, hiding outlier dots for readability.
    plt.figure(figsize=(7, 4))
    data.boxplot(column="url_length", by=LABEL_COLUMN, showfliers=False)
    plt.title("URL Length by Class")
    plt.suptitle("")
    plt.xlabel("Label (0 = legitimate, 1 = phishing)")
    plt.ylabel("URL length")
    plt.tight_layout()
    plt.savefig(GRAPH_FOLDER / "url_length_by_label.png", dpi=150)
    plt.close()

    # Graph 3: show correlations between the strongest numeric features and label.
    correlations = data[number_features].corrwith(data[LABEL_COLUMN]).abs()
    columns = correlations.nlargest(10).index.tolist() + [LABEL_COLUMN]
    matrix = data[columns].corr()
    size = max(7, len(columns) * 0.65)
    figure, axis = plt.subplots(figsize=(size, size))
    image = axis.imshow(matrix, cmap="coolwarm", vmin=-1, vmax=1)
    axis.set_xticks(range(len(columns)), labels=columns, rotation=90)
    axis.set_yticks(range(len(columns)), labels=columns)
    axis.set_title("Correlation Heatmap")
    figure.colorbar(image, ax=axis)
    figure.tight_layout()
    figure.savefig(GRAPH_FOLDER / "feature_correlation_heatmap.png", dpi=150)
    plt.close(figure)


def train_model(data, number_features):
    """Train the URL character n-gram SVM and save its evaluation outputs."""
    RESULT_FOLDER.mkdir(parents=True, exist_ok=True)

    # URL characters and numeric features both go into the one chosen model.
    # Fit all feature processing on training data only to avoid test-data leakage.
    preprocessing = ColumnTransformer(
        [
            (
                "url_characters",
                TfidfVectorizer(
                    analyzer="char_wb",
                    ngram_range=(2, 6),
                    min_df=2,
                    max_features=300_000,
                    sublinear_tf=True,
                    dtype=np.float32,
                ),
                URL_COLUMN,
            ),
            (
                "numeric_features",
                Pipeline(
                    [
                        ("fill_missing", SimpleImputer(strategy="median")),
                        ("scale", StandardScaler(with_mean=False)),
                    ]
                ),
                number_features,
            ),
        ],
        remainder="drop",
        sparse_threshold=1.0,
    )

    # This is the same classifier setup and random split used for the existing
    # 97.87% result, so the result can be compared fairly with the saved report.
    model = Pipeline(
        [
            ("prepare_features", preprocessing),
            (
                "classifier",
                LinearSVC(
                    C=2.0,
                    max_iter=2_000,
                    tol=1e-2,
                    random_state=RANDOM_SEED,
                ),
            ),
        ]
    )
    train_data, test_data = train_test_split(
        data,
        test_size=0.2,
        random_state=RANDOM_SEED,
        stratify=data[LABEL_COLUMN],
    )
    SPLIT_FOLDER.mkdir(parents=True, exist_ok=True)
    train_data.to_csv(
        SPLIT_FOLDER / "training_dataset.csv",
        index=True,
        index_label="cleaned_row_index",
    )
    test_data.to_csv(
        SPLIT_FOLDER / "test_dataset.csv",
        index=True,
        index_label="cleaned_row_index",
    )
    model.fit(train_data, train_data[LABEL_COLUMN])
    predictions = model.predict(test_data)
    actual = test_data[LABEL_COLUMN]

    # Report class 1 as phishing. Do not change the held-out test labels.
    scores = {
        "model": "Character n-gram Linear SVM",
        "accuracy": accuracy_score(actual, predictions),
        "precision_phishing": precision_score(
            actual, predictions, pos_label=1, zero_division=0
        ),
        "recall_phishing": recall_score(
            actual, predictions, pos_label=1, zero_division=0
        ),
        "f1_phishing": f1_score(actual, predictions, pos_label=1, zero_division=0),
        "train_records": len(train_data),
        "test_records": len(test_data),
        "random_seed": RANDOM_SEED,
        "positive_label": 1,
    }
    pd.DataFrame([scores]).to_csv(RESULT_FOLDER / "metrics.csv", index=False)

    # Save the confusion matrix as a table and an easy-to-read graph.
    matrix = confusion_matrix(actual, predictions, labels=[0, 1])
    pd.DataFrame(
        matrix,
        index=["Actual legitimate (0)", "Actual phishing (1)"],
        columns=["Predicted legitimate (0)", "Predicted phishing (1)"],
    ).to_csv(RESULT_FOLDER / "confusion_matrix.csv")
    display = ConfusionMatrixDisplay(
        confusion_matrix=matrix,
        display_labels=["Legitimate", "Phishing"],
    )
    display.plot(cmap="Blues", values_format="d")
    plt.title("URL SVM Confusion Matrix")
    plt.tight_layout()
    plt.savefig(RESULT_FOLDER / "confusion_matrix.png", dpi=150)
    plt.close()

    # Keep the model and the feature column names needed to use it again.
    joblib.dump(
        {"model": model, "number_features": number_features},
        RESULT_FOLDER / "phishing_url_model.joblib",
    )

    # Write the measured scores and classification report for submission.
    report = f"""# URL Phishing Classifier Results

- Model: Character n-gram Linear SVM
- Accuracy: {scores["accuracy"]:.2%}
- Precision for phishing: {scores["precision_phishing"]:.2%}
- Recall for phishing: {scores["recall_phishing"]:.2%}
- F1-score for phishing: {scores["f1_phishing"]:.2%}
- Training rows: {len(train_data):,}
- Test rows: {len(test_data):,}
- Random seed: {RANDOM_SEED}

Label 1 means phishing; label 0 means legitimate. These results are measured
on a held-out portion of this dataset and do not guarantee future performance.
The SVM may show a convergence warning because it reached its configured
iteration limit; report this caveat with the result.

The exact train/test CSV files used for this evaluation are saved under
`splits/`. Their `cleaned_row_index` column maps each split row to its
zero-based data-row position in the cleaned input CSV and is not a model feature.

## Classification report

```text
{classification_report(actual, predictions, target_names=["Legitimate", "Phishing"], zero_division=0).rstrip()}
```
"""
    (RESULT_FOLDER / "report.md").write_text(report, encoding="utf-8")

    print(f"Accuracy: {scores['accuracy']:.2%}")
    print(f"Phishing precision: {scores['precision_phishing']:.2%}")
    print(f"Phishing recall: {scores['recall_phishing']:.2%}")
    print(f"Phishing F1-score: {scores['f1_phishing']:.2%}")
    if scores["accuracy"] < 0.97:
        print("Note: this run did not reach 97% accuracy.")
    print(f"Saved results in: {RESULT_FOLDER}")


def main():
    """Load the saved cleaned data, draw its graphs, and train the SVM."""
    if not DATA_FILE.is_file():
        raise FileNotFoundError(
            f"Cleaned CSV not found: {DATA_FILE}\n"
            "Keep phishing_url_cleaned_100000.csv beside this script."
        )

    data = pd.read_csv(DATA_FILE)
    if URL_COLUMN not in data.columns or LABEL_COLUMN not in data.columns:
        raise ValueError("The CSV must contain 'url' and 'label' columns.")
    if set(data[LABEL_COLUMN].dropna().unique()) != {0, 1}:
        raise ValueError("The label column must contain both 0 and 1.")

    number_features = [
        column for column in data.columns if column not in (URL_COLUMN, LABEL_COLUMN)
    ]
    data[number_features] = data[number_features].apply(
        pd.to_numeric, errors="coerce"
    )
    print(f"Loaded {len(data):,} rows and {len(number_features)} numeric features.")

    make_dataset_graphs(data, number_features)
    train_model(data, number_features)
    print(f"Dataset graphs saved in: {GRAPH_FOLDER}")


if __name__ == "__main__":
    main()
