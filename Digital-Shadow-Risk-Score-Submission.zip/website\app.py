from __future__ import annotations

import ipaddress
import math
import os
import re
import string
from collections import Counter
from pathlib import Path
from urllib.parse import parse_qsl, urlsplit, urlunsplit

import joblib
import pandas as pd
from flask import Flask, jsonify, render_template, request


MODEL_PATH = (
    Path(__file__).resolve().parent.parent
    / "Final"
    / "url_svm_output"
    / "phishing_url_model.joblib"
)
METRICS_PATH = MODEL_PATH.parent / "metrics.csv"
CONFUSION_MATRIX_PATH = MODEL_PATH.parent / "confusion_matrix.csv"
QUESTION_GROUPS = {
    "privacy": 3,
    "identity": 3,
    "impersonation": 3,
}
RISK_WEIGHTS = {
    "privacy": 30,
    "identity": 25,
    "impersonation": 20,
    "phishing": 25,
}
SUSPICIOUS_TLDS = {
    "click",
    "country",
    "gq",
    "icu",
    "link",
    "monster",
    "online",
    "rest",
    "shop",
    "top",
    "work",
    "xyz",
}
BRAND_TERMS = {"amazon", "apple", "facebook", "google", "microsoft", "netflix", "paypal"}
OFFICIAL_DOMAINS = {
    "amazon.com",
    "apple.com",
    "facebook.com",
    "google.com",
    "microsoft.com",
    "netflix.com",
    "paypal.com",
}
GOOGLE_OFFICIAL_DOMAINS = {
    "google.com",
    "google.ad",
    "google.ae",
    "google.al",
    "google.am",
    "google.as",
    "google.at",
    "google.az",
    "google.ba",
    "google.be",
    "google.bf",
    "google.bg",
    "google.bi",
    "google.bj",
    "google.bs",
    "google.bt",
    "google.by",
    "google.ca",
    "google.cat",
    "google.cd",
    "google.cf",
    "google.cg",
    "google.ch",
    "google.ci",
    "google.cl",
    "google.cm",
    "google.cn",
    "google.co.ao",
    "google.co.bw",
    "google.co.ck",
    "google.co.cr",
    "google.co.id",
    "google.co.il",
    "google.co.in",
    "google.co.jp",
    "google.co.ke",
    "google.co.kr",
    "google.co.ls",
    "google.co.ma",
    "google.co.mz",
    "google.co.nz",
    "google.co.th",
    "google.co.tz",
    "google.co.ug",
    "google.co.uk",
    "google.co.uz",
    "google.co.ve",
    "google.co.vi",
    "google.co.za",
    "google.co.zm",
    "google.co.zw",
    "google.com.af",
    "google.com.ag",
    "google.com.ai",
    "google.com.ar",
    "google.com.au",
    "google.com.bd",
    "google.com.bh",
    "google.com.bn",
    "google.com.bo",
    "google.com.br",
    "google.com.bz",
    "google.com.co",
    "google.com.cu",
    "google.com.cy",
    "google.com.do",
    "google.com.ec",
    "google.com.eg",
    "google.com.et",
    "google.com.fj",
    "google.com.gh",
    "google.com.gi",
    "google.com.gt",
    "google.com.hk",
    "google.com.jm",
    "google.com.kh",
    "google.com.kw",
    "google.com.lb",
    "google.com.ly",
    "google.com.mm",
    "google.com.mt",
    "google.com.mx",
    "google.com.my",
    "google.com.na",
    "google.com.nf",
    "google.com.ng",
    "google.com.ni",
    "google.com.np",
    "google.com.om",
    "google.com.pa",
    "google.com.pe",
    "google.com.pg",
    "google.com.ph",
    "google.com.pk",
    "google.com.pr",
    "google.com.py",
    "google.com.qa",
    "google.com.sa",
    "google.com.sb",
    "google.com.sg",
    "google.com.sl",
    "google.com.sv",
    "google.com.tj",
    "google.com.tr",
    "google.com.tw",
    "google.com.ua",
    "google.com.uy",
    "google.com.vc",
    "google.com.vn",
    "google.cz",
    "google.de",
    "google.dj",
    "google.dk",
    "google.dm",
    "google.dz",
    "google.ee",
    "google.es",
    "google.fi",
    "google.fm",
    "google.fr",
    "google.ga",
    "google.ge",
    "google.gg",
    "google.gl",
    "google.gm",
    "google.gr",
    "google.gy",
    "google.hn",
    "google.hr",
    "google.ht",
    "google.hu",
    "google.ie",
    "google.im",
    "google.iq",
    "google.is",
    "google.it",
    "google.je",
    "google.jo",
    "google.kg",
    "google.ki",
    "google.kz",
    "google.la",
    "google.li",
    "google.lk",
    "google.lt",
    "google.lu",
    "google.lv",
    "google.md",
    "google.me",
    "google.mg",
    "google.mk",
    "google.ml",
    "google.mn",
    "google.ms",
    "google.mu",
    "google.mv",
    "google.mw",
    "google.ne",
    "google.nl",
    "google.no",
    "google.nr",
    "google.nu",
    "google.pl",
    "google.ps",
    "google.pt",
    "google.ro",
    "google.rs",
    "google.ru",
    "google.rw",
    "google.sc",
    "google.se",
    "google.sh",
    "google.si",
    "google.sk",
    "google.sm",
    "google.sn",
    "google.so",
    "google.sr",
    "google.st",
    "google.td",
    "google.tg",
    "google.tk",
    "google.tl",
    "google.tm",
    "google.tn",
    "google.to",
    "google.tt",
    "google.vg",
    "google.vu",
    "google.ws",
}
MODEL_BUNDLE = joblib.load(MODEL_PATH)
MODEL = MODEL_BUNDLE["model"]
FEATURE_COLUMNS = MODEL_BUNDLE["number_features"]
METRICS = pd.read_csv(METRICS_PATH)
CONFUSION_MATRIX = pd.read_csv(CONFUSION_MATRIX_PATH, index_col=0)
if len(METRICS) != 1:
    raise RuntimeError(f"Expected one model metrics row in {METRICS_PATH}.")
if CONFUSION_MATRIX.shape != (2, 2):
    raise RuntimeError(f"Expected a 2x2 confusion matrix in {CONFUSION_MATRIX_PATH}.")
METRIC_ROW = METRICS.iloc[0]
MATRIX_VALUES = CONFUSION_MATRIX.to_numpy()
MODEL_EVALUATION = {
    "name": METRIC_ROW["model"],
    "numeric_feature_count": len(FEATURE_COLUMNS),
    "accuracy": round(float(METRIC_ROW["accuracy"]) * 100, 2),
    "precision": round(float(METRIC_ROW["precision_phishing"]) * 100, 2),
    "recall": round(float(METRIC_ROW["recall_phishing"]) * 100, 2),
    "f1": round(float(METRIC_ROW["f1_phishing"]) * 100, 2),
    "training_records": int(METRIC_ROW["train_records"]),
    "test_records": int(METRIC_ROW["test_records"]),
    "dataset_records": int(METRIC_ROW["train_records"] + METRIC_ROW["test_records"]),
    "legitimate_records": int(
        MATRIX_VALUES[0].sum() + int(METRIC_ROW["train_records"]) // 2
    ),
    "phishing_records": int(
        MATRIX_VALUES[1].sum() + int(METRIC_ROW["train_records"]) // 2
    ),
    "random_seed": int(METRIC_ROW["random_seed"]),
    "notebook_comparison": {
        "test_records": 20_000,
        "decision_tree_accuracy": round((9_352 + 9_010) / 20_000 * 100, 2),
        "random_forest_accuracy": round((9_777 + 9_653) / 20_000 * 100, 2),
    },
    "confusion_matrix": {
        "true_legitimate": int(MATRIX_VALUES[0, 0]),
        "false_phishing": int(MATRIX_VALUES[0, 1]),
        "missed_phishing": int(MATRIX_VALUES[1, 0]),
        "true_phishing": int(MATRIX_VALUES[1, 1]),
    },
}

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024


def risk_level(score: int) -> str:
    if score < 34:
        return "Low"
    if score < 67:
        return "Moderate"
    return "High"


def entropy(value: str) -> float:
    if not value:
        return 0.0
    counts = Counter(value)
    length = len(value)
    return -sum(
        (count / length) * math.log2(count / length) for count in counts.values()
    )


def normalize_url(raw_url: str) -> str:
    value = raw_url.strip()
    if not value:
        raise ValueError("Enter a URL to check.")
    if len(value) > 2048:
        raise ValueError("The URL must be 2,048 characters or fewer.")
    if "://" not in value:
        value = f"https://{value}"

    try:
        parsed = urlsplit(value)
        hostname = (parsed.hostname or "").rstrip(".").lower()
        port = parsed.port
    except ValueError as error:
        raise ValueError("Enter a valid URL, including a hostname.") from error
    if not hostname:
        raise ValueError("Enter a valid URL, including a hostname.")
    try:
        ipaddress.ip_address(hostname)
    except ValueError:
        try:
            ascii_hostname = hostname.encode("idna").decode("ascii")
        except UnicodeError as error:
            raise ValueError("Enter a valid URL, including a hostname.") from error
        labels_to_check = ascii_hostname.split(".")
        if any(
            not label
            or len(label) > 63
            or not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?", label)
            for label in labels_to_check
        ):
            raise ValueError("Enter a valid URL, including a hostname.")

    if not parsed.path:
        parsed = parsed._replace(path="/")
        value = urlunsplit(parsed)
    return value


def is_official_domain(hostname: str) -> bool:
    if hostname == "sites.google.com" or hostname.endswith(".sites.google.com"):
        return False
    return any(
        hostname == domain or hostname.endswith(f".{domain}")
        for domain in OFFICIAL_DOMAINS | GOOGLE_OFFICIAL_DOMAINS
    )


def make_url_features(raw_url: str) -> dict[str, float]:
    value = normalize_url(raw_url)
    parsed = urlsplit(value)
    hostname = (parsed.hostname or "").rstrip(".").lower()
    port = parsed.port
    path = parsed.path or ""
    query = parsed.query or ""
    path_segments = [part for part in path.split("/") if part]
    query_pairs = parse_qsl(query, keep_blank_values=True)
    labels = hostname.split(".")
    tld = labels[-1] if len(labels) > 1 else ""
    domain = ".".join(labels[-2:]) if len(labels) > 1 else hostname
    url_lower = value.lower()
    letters = sum(character.isalpha() for character in value)
    digits = sum(character.isdigit() for character in value)
    special_characters = sum(not character.isalnum() for character in value)
    total = max(len(value), 1)
    try:
        ipaddress.ip_address(hostname)
        is_ip_address = 1.0
    except ValueError:
        is_ip_address = 0.0

    features = {
        "url_length": float(len(value)),
        "domain_length": float(len(domain)),
        "hostname_length": float(len(hostname)),
        "path_length": float(len(path)),
        "first_dir_length": float(len(path_segments[0]) if path_segments else 0),
        "tld_length": float(len(tld)),
        "tld_length_domain": float(len(f".{tld}") if tld else 0),
        "url_depth": float(len(path_segments)),
        "query_length": float(len(query)),
        "path_segments_count": float(len(path_segments)),
        "num_digits": float(digits),
        "num_letters": float(letters),
        "num_special_chars": float(special_characters),
        "num_dots": float(value.count(".")),
        "num_hyphens": float(value.count("-")),
        "num_at": float(value.count("@")),
        "num_percent": float(value.count("%")),
        "num_equals": float(value.count("=")),
        "num_question": float(value.count("?")),
        "num_ampersand": float(value.count("&")),
        "num_hash": float(value.count("#")),
        "num_underscore": float(value.count("_")),
        "num_special": float(
            sum(character in string.punctuation for character in value)
        ),
        "num_slash": float(value.count("/")),
        "num_params": float(len(query_pairs)),
        "entropy_url": entropy(value),
        "entropy_hostname": entropy(hostname),
        "entropy_domain": entropy(domain),
        "entropy_path": entropy(path),
        "query_entropy": entropy(query),
        "ratio_digits": digits / total,
        "ratio_letters": letters / total,
        "ratio_special_chars": special_characters / total,
        "uppercase_ratio": sum(character.isupper() for character in value) / total,
        "lowercase_ratio": sum(character.islower() for character in value) / total,
        "is_ip_address": is_ip_address,
        "starts_with_ip": is_ip_address,
        "is_suspicious_tld": float(tld in SUSPICIOUS_TLDS),
        "uses_https": float(parsed.scheme.lower() == "https"),
        "has_www": float(hostname.startswith("www.")),
        "unusual_double_slash": float("//" in path),
        "multiple_http": float(url_lower.count("http") > 1),
        "contains_port_number": float(port is not None),
        "path_has_encoded_chars": float(bool(re.search(r"%[0-9a-fA-F]{2}", path))),
        "query_has_base64": float(
            bool(re.search(r"(?:^|[=&])[A-Za-z0-9+/]{16,}={0,2}(?:&|$)", query))
        ),
        "contains_login": float("login" in url_lower),
        "contains_secure": float("secure" in url_lower),
        "contains_verify": float("verify" in url_lower),
        "contains_account": float("account" in url_lower),
        "contains_update": float("update" in url_lower),
        "contains_bank": float("bank" in url_lower),
        "contains_cloud": float("cloud" in url_lower),
        "contains_brand": float(any(term in url_lower for term in BRAND_TERMS)),
        "query_key_count": float(sum(bool(key) for key, _ in query_pairs)),
        "query_value_length_avg": (
            sum(len(item) for _, item in query_pairs) / len(query_pairs)
            if query_pairs
            else 0.0
        ),
    }
    missing = set(FEATURE_COLUMNS) - features.keys()
    if missing:
        raise RuntimeError(
            f"URL feature extractor is missing model inputs: {sorted(missing)}"
        )
    return features


def calculate_assessment(
    answers: dict[str, list[int]], phishing_score: int | None
) -> dict[str, object]:
    components: dict[str, int | None] = {}
    for group, question_count in QUESTION_GROUPS.items():
        values = answers.get(group)
        if (
            not isinstance(values, list)
            or len(values) != question_count
            or any(type(value) is not int or value not in (0, 1, 2) for value in values)
        ):
            raise ValueError(f"Please answer all {group} questions.")
        components[group] = round(sum(values) / (question_count * 2) * 100)

    components["phishing"] = phishing_score
    active_weights = {
        group: weight
        for group, weight in RISK_WEIGHTS.items()
        if group != "phishing" or phishing_score is not None
    }
    weight_total = sum(active_weights.values())
    overall = round(
        sum(
            int(components[group]) * weight
            for group, weight in active_weights.items()
        )
        / weight_total
    )
    return {
        "components": {
            group: {
                "score": score,
                "level": risk_level(score) if score is not None else "Not checked",
            }
            for group, score in components.items()
        },
        "overall_score": overall,
        "overall_level": risk_level(overall),
    }


@app.get("/")
def home():
    return render_template("index.html", model_evaluation=MODEL_EVALUATION)


@app.post("/api/assess")
def assess():
    if not request.is_json:
        return jsonify(error="Send assessment answers as JSON."), 400
    payload = request.get_json()
    if not isinstance(payload, dict) or not isinstance(payload.get("answers"), dict):
        return jsonify(error="Assessment answers are missing or invalid."), 400

    phishing_score = payload.get("phishing_score")
    if phishing_score is not None and (
        type(phishing_score) is not int or not 0 <= phishing_score <= 100
    ):
        return jsonify(error="The phishing score must be between 0 and 100."), 400
    try:
        result = calculate_assessment(payload["answers"], phishing_score)
    except ValueError as error:
        return jsonify(error=str(error)), 400
    return jsonify(result)


@app.post("/api/check-url")
def check_url():
    if not request.is_json:
        return jsonify(error="Send the URL as JSON."), 400
    payload = request.get_json()
    if not isinstance(payload, dict) or not isinstance(payload.get("url"), str):
        return jsonify(error="Enter a URL to check."), 400

    try:
        normalized_url = normalize_url(payload["url"])
        features = make_url_features(normalized_url)
    except ValueError as error:
        return jsonify(error=str(error)), 400
    missing_features = set(FEATURE_COLUMNS) - features.keys()
    if missing_features:
        raise RuntimeError(
            f"URL feature extractor is missing model inputs: {sorted(missing_features)}"
        )
    model_input = pd.DataFrame(
        [
            {
                "url": normalized_url,
                **{column: features[column] for column in FEATURE_COLUMNS},
            }
        ],
        columns=["url", *FEATURE_COLUMNS],
    )
    prediction = int(MODEL.predict(model_input)[0])
    margin = float(MODEL.decision_function(model_input)[0])
    phishing_score = round(
        100 / (1 + math.exp(-max(-20.0, min(20.0, margin))))
    )
    hostname = (urlsplit(normalized_url).hostname or "").lower()
    official_domain = is_official_domain(hostname)
    if official_domain:
        prediction = 0
        phishing_score = 0
        note = (
            "A known official brand domain was recognized, so its SVM result was "
            "overridden. Check the exact hostname; lookalike and user-hosted "
            "domains are not covered by this rule."
        )
    else:
        note = (
            "The risk indicator is derived from the SVM decision margin, not a "
            "calibrated probability. The site analyzes URL text only and does "
            "not visit the link."
        )
    return jsonify(
        classification="Phishing" if prediction == 1 else "Likely legitimate",
        phishing_score=phishing_score,
        official_domain=official_domain,
        model=MODEL_EVALUATION["name"],
        note=note,
    )


if __name__ == "__main__":
    app.run(
        host="127.0.0.1",
        port=int(os.environ.get("DIGITAL_SHADOW_PORT", "5000")),
        debug=False,
    )
